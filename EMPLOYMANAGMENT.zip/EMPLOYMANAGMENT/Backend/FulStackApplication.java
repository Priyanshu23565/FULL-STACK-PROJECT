package com.example.Ful_Stack;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class FulStackApplication {

	public static void main(String[] args) {
		SpringApplication.run(FulStackApplication.class, args);
	}

}
